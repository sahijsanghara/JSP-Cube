package testpack;

public class Cube {
	private int side;

	public Cube() {
		super();

	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}
	
	public int getVolume() {
		return side * side * side;
	}
	
}
